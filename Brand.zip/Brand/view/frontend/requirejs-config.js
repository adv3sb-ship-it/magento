var config = {
    config: {
        mixins: {
            'Magento_Theme/js/view/breadcrumbs': {
                'Mirasvit_Brand/js/product/breadcrumbs': true
            }
        }
    }
};
